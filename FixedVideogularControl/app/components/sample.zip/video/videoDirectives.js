(function () {
    "use strict";
    var vcVideoModule = angular.module('vc.video', [
        "com.2fdevs.videogular",
        "com.2fdevs.videogular.plugins.controls",
        "com.2fdevs.videogular.plugins.poster",
        "com.2fdevs.videogular.plugins.buffering",
         "com.2fdevs.videogular.plugins.overlayplay",
       
        "info.vietnamcode.nampnq.videogular.plugins.flash"
    ]);

    vcVideoModule
        .config([
            '$provide',
            function ($provide) {
                $provide.decorator('vgBufferingDirective', function ($delegate) {
                    var vgBufferingDirective = $delegate[0];
                    var originalLinkFn = angular.copy(vgBufferingDirective.link);
                    vgBufferingDirective.compile = function () {
                        return function ($scope, elem, $attrs, API) {
                            originalLinkFn.apply(this, arguments);
                            var spinner = angular.element(elem[0].getElementsByClassName("loadingSpinner"));
                            function hideBuffering() {
                                console.log("d");
                                 spinner.addClass("stop");
                                elem.css("display", "none");
                            }
                            API.$on('loadedmetadata', hideBuffering);
                        };
                    };
                    return $delegate;
                });
            }]);

    vcVideoModule
        .config([
            '$provide',
            function ($provide) {
                $provide.decorator('vgPosterImageDirective', function ($delegate, $window) {
                    var vgPosterImageDirective = $delegate[0];
                    var originalLinkFn = angular.copy(vgPosterImageDirective.link);
                    vgPosterImageDirective.compile = function () {
                        return function (scope, elem, $attrs, API) {
                            originalLinkFn.apply(this, arguments);
                            scope.$on('showPoster', function () {
                                elem.css("display", "block");
                            });
                        };
                    };
                    return $delegate;
                });
            }]);
    vcVideoModule.directive('apiConnector', function () {
            return {restrict: "E",
                require: ['^vcMediaVideoContainer', '^videogular'],
                link: function ($scope, $element, $atts, $controllers) {
                    $controllers[0].setAPI($controllers[1]);
                }
            };
        }
    );

    vcVideoModule.directive('vcMediaVideoContainer', function ($sce, $timeout) {
        return {restrict: "E",
            scope: {
                file: '=',
                mediaTime: '='
            },
            replace: true,
            templateUrl: 'media/videoContainer.html',
            controller: function ($scope, $element, $attrs) {
                $scope.config = {
                    media: [],
                    responsive: true,
                    stretch: 'fit',
                    poster: {url: ''},
                    autoHide: false,
//                    autoHideTime: 200,
                    autoPlay: false
                };
               
                this.setAPI = function (APIObj) {
                    $scope.API = APIObj;
                };
                $scope.decodeEntities = function (text) {
                    var entities = [
                        ['amp', '&']
                    ];
                    for (var i = 0, max = entities.length; i < max; ++i)
                        text = text.replace(new RegExp('&' + entities[i][0] + ';', 'g'), entities[i][1]);

                    return text;
                };
            },
            link: function ($scope, $element, $attrs) {
              
                if (typeof $scope.mediaTime == 'undefined') {
                    $scope.mediaTime = {};
                }
             
                $scope.$on('onVgUpdateTime', function (e, data) {
                    $scope.mediaTime.current = data[0];
                    $scope.mediaTime.total = data[1];
                });
                var videoReady = false;
                $scope.$on('onVgPlayerReady', function () {
                    videoReady = true;
                });
                $scope.$on('videoSeekTime', function (e, data) {
                    if ($scope.API && !isNaN(data) && videoReady) {
                        $scope.API.seekTime(data);
                    }
                });
                $scope.$on('videoPause', function () {
                    if ($scope.API) {
                        $scope.API.pause();
                    }
                });
              
                $scope.$on('videoPlay', function () {
                    if ($scope.API) {
                        $scope.API.play();
                    }
                });
                $scope.$on('onVgPlayerReady', function () {
                    $timeout(function () {
                        if ($scope.API){
                            $scope.API.pause();}
                        $scope.$broadcast('showPoster');
                    }, 70);
                });
                
               
                if ($scope.file && $scope.file.dl_link) {
                    var sourceMedia = {src: $sce.trustAsResourceUrl($scope.decodeEntities($scope.file.dl_link)), type: 'video/mp4'};
                    $scope.config.media.push(sourceMedia);
                   
                    $scope.config.poster.url = $sce.trustAsResourceUrl($scope.file.thumbnail);
                }
            }
        };
    });
}());
